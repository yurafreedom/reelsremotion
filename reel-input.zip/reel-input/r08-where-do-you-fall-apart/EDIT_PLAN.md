# Edit plan — R08 Where Do You Fall Apart?

Status: proposal; timings below are Reel-relative targets, not an approved v3 timeline.

- **00:00–00:01.3 — HOOK CARD:** Where do you fall apart?
- **00:01.3–00:32 — SOURCE:** r08-observe-parts after audio correction of ASR terms.
- **00:32–00:33.2 — PUNCH CARD:** Protective parts / self-naming transition.
- **00:33.2–~01:02.8 — SOURCE PAYOFF:** r08-protective-parts; attribution and wording review required.

## Timeline rules

- Primary source audio remains continuous inside each approved source clip.
- B-roll changes only the visual layer; subtitle timing remains anchored to source audio.
- Generate v3 absolute frames only after this plan and DISPLAY RU are approved.
- No final Reel is rendered in this phase.

