# Edit plan — R04 Compromise vs Consensus

Status: proposal; timings below are Reel-relative targets, not an approved v3 timeline.

- **00:00–00:01.3 — HOOK CARD:** Compromise vs consensus.
- **00:01.3–00:34 — SOURCE PRINCIPLE:** r04-principle after transcript corruption is reviewed.
- **00:34–00:35.2 — TIMECODE-JUMP CARD:** Signal a new practical example.
- **00:35.2–~01:10 — SOURCE EXAMPLE:** r04-example, tightened by complete clauses.

## Timeline rules

- Primary source audio remains continuous inside each approved source clip.
- B-roll changes only the visual layer; subtitle timing remains anchored to source audio.
- Generate v3 absolute frames only after this plan and DISPLAY RU are approved.
- No final Reel is rendered in this phase.

