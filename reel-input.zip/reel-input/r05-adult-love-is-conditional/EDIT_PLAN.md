# Edit plan — R05 Adult Love Is Conditional

Status: proposal; timings below are Reel-relative targets, not an approved v3 timeline.

- **00:00–00:01.4 — HOOK CARD:** Adult love is conditional—clearly editorial text.
- **00:01.4–00:17 — SOURCE:** Acceptance and thesis.
- **00:17–00:18 — PUNCH CARD:** The maturation turn.
- **00:18–~00:49 — SOURCE PAYOFF:** Conditions/boundaries and structure; explicit language review required.

## Timeline rules

- Primary source audio remains continuous inside each approved source clip.
- B-roll changes only the visual layer; subtitle timing remains anchored to source audio.
- Generate v3 absolute frames only after this plan and DISPLAY RU are approved.
- No final Reel is rendered in this phase.

