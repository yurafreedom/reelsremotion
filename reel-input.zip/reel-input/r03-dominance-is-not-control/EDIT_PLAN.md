# Edit plan — R03 Dominance Is Not Control

Status: proposal; timings below are Reel-relative targets, not an approved v3 timeline.

- **00:00–00:01.2 — HOOK CARD:** Dominance is not control.
- **00:01.2–00:31 — SOURCE:** Calm/structure example; stable body subtitles.
- **00:31–00:32 — PACE RESET:** Minimal wine-red card, no B-roll required.
- **00:32–~00:48 — SOURCE PAYOFF:** Keep the source definition visible and unbroken.

## Timeline rules

- Primary source audio remains continuous inside each approved source clip.
- B-roll changes only the visual layer; subtitle timing remains anchored to source audio.
- Generate v3 absolute frames only after this plan and DISPLAY RU are approved.
- No final Reel is rendered in this phase.

