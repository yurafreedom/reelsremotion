# Edit plan — R01 Fear of Losing Yourself

Status: proposal; timings below are Reel-relative targets, not an approved v3 timeline.

- **00:00–00:01.3 — HOOK CARD:** Editorial card; clearly not presented as a quote.
- **00:01.3–00:24.8 — SOURCE:** r01-hook-loss; stable subtitles, one emphasis on «теряешь себя».
- **00:24.8–00:26.0 — PUNCH CARD:** Short clarity reset.
- **00:26.0–~01:05.7 — SOURCE:** r01-clarity-ground; trim club-specific material only after review.

## Timeline rules

- Primary source audio remains continuous inside each approved source clip.
- B-roll changes only the visual layer; subtitle timing remains anchored to source audio.
- Generate v3 absolute frames only after this plan and DISPLAY RU are approved.
- No final Reel is rendered in this phase.

